# Portfolio content inventory

Research notes reconciled against the user-provided CV master facts (last reconciled 4 October 2026), the public [LinkedIn profile](https://linkedin.com/in/moiz-irshad/) and the public [GitHub profile](https://github.com/moizirshad). LinkedIn access was incomplete, so the CV is the primary source for roles, dates, outcomes and technical scope. Public GitHub repository visibility was checked from the profile.

## Verified project inventory

| Project | Evidence-backed scope | Platforms / technologies represented | Source and limits |
|---|---|---|---|
| FITT Meals | Built iOS and Android apps from scratch as the sole Flutter developer. Meal plans, checkout, payments, loyalty, referrals, order history, caching, local persistence and reusable UI. | Flutter, Dart, Riverpod, BLoC, REST integration, Stripe, Firebase Analytics, Crashlytics, Sentry, Fastlane | CV. Business scale is 2,500+ customers and 40,000+ meals/week; no app usage, rating or crash metric is attributed. NutriBot implementation details are unconfirmed. |
| DubiCars | Senior software engineer across iOS, Android and Flutter. Cross-platform feature time improved by 40%; iOS startup time −50%, memory −35%; release time 4 hours to 30 minutes. Listings, search, messaging, payments and delivery tracking. | Swift, Kotlin, Flutter, Dart, REST, WebSockets, Fastlane, GitHub Actions | CV. 500K+ downloads, 4.5+ rating and 99%+ crash-free are product-wide figures. Flutter migration sequence is unconfirmed. Dubi Hero of the Month, February 2025. |
| Bykea | Sole iOS engineer on location, routing, driver matching and payment experiences; App Store, TestFlight and certificates. | Swift, UIKit, MapKit, Core Location, WebSockets | CV. 2M+ DAU, 99%+ crash-free and 4.5+ rating are platform-wide figures. |
| Danat eVentures | Mobile engineer then lead; led six mobile engineers and three QA; client work across finance, real estate and e-commerce; standardized MVVM; reviews, roadmap, sprint planning, client HLD/LLD; mentored two engineers. | iOS, Android team delivery; Swift, Objective-C, Java, Kotlin, MVVM, CI/CD | CV. 12+ applications, 500K+ combined users, 95%+ client satisfaction, 35% fewer production bugs. These figures describe team/client delivery, not an individual app. May 2022 end month is marked for confirmation in the CV source. |
| Argaam | Native iOS work on financial news and live market information. | Swift, UIKit, REST APIs | CV and public profile. Detailed architecture and verified store links were unavailable. |
| Akhbaar24 | Native iOS contribution to news and live sports product. | Swift, UIKit, REST APIs | CV and public profile. Detailed architecture and verified store links were unavailable. |

## Other verified professional details

- FITT Meals (Mar 2026–present), DubiCars (Apr 2021–Mar 2026), Bykea (May 2022–Mar 2023), Danat eVentures (Feb 2016–May 2022 across two roles), Innovative Solutions (Dec 2014–Jan 2016), SysTellex Inc. (Aug–Nov 2014).
- Total career spans 12+ years from August 2014. The DubiCars role overlapped with Danat eVentures and Bykea; the timeline preserves those dates.
- 4.5+ years in a formal Mobile Development Lead role at Danat eVentures.
- AI-assisted development tools named in the CV include Claude, Claude Code, Cursor and coding agents. No AI/ML engineering project or measured AI productivity result is claimed.
- React Native is listed in the CV skill set, but no verified production case study has been identified; the site labels that gap.
- Backend evidence supports mobile API design collaboration/integration, REST, GraphQL, WebSockets, OAuth 2.0, JWT and Firebase. It does not support claiming production authorship of a Node.js/NestJS/PostgreSQL backend.

## Public code checked

- [how_to_set_app_architecture](https://github.com/moizirshad/how_to_set_app_architecture)
- [flutter_facebook_login_page](https://github.com/moizirshad/flutter_facebook_login_page)
- [Argaam_Flutter](https://github.com/moizirshad/Argaam_Flutter)

These are displayed as public code samples, not as source code for client/employer products. DubiCars, Bykea, FITT Meals and Danat repositories found on the account are private and are not linked as open source.

## Missing material

- Approved application screenshots, demos, App Store and Google Play URLs.
- Detailed implementation/architecture notes for each product, beyond what the CV verifies.
- React Native production project name and role, if applicable.
- NutriBot implementation details and exact DubiCars Flutter migration method.
- Confirmation of Danat's end month and DubiCars work mode.
- FITT app metrics and a measurable AI-assisted engineering example.
